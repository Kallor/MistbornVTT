export class PlayerSidebar extends Application {
    constructor(options = {}) {
        super(options);
        PlayerSidebar.instance = this;
        // You can initialize more stuff here if needed
    }

    static get defaultOptions() {
        const options = super.defaultOptions;
        options.id = "player-sidebar";
        options.template = "systems/mistborn/templates/sidebar/player-sidebar.hbs";
        options.title = "Player Sidebar";
        // Define other options as needed
        return options;
    }

    getData() {
        let actorData = {};
    
        if (game.user.isGM) {
            // For GM: Get tokens from the current combat encounter
            if (game.combat) {
                const combatantTokens = game.combat.combatants.map(combatant => {
                    return canvas.tokens.get(combatant.tokenId);
                });
    
                // Process combatantTokens to extract and aggregate data
                // Example: Getting the first token's data
                if (combatantTokens.length > 0 && combatantTokens[0].actor) {
                    const actor = combatantTokens[0].actor;
                    actorData = {
                        // ... extract actor data ...
                        health: character.system.health,
                        reputation: character.system.reputation,
                        willpower: character.system.willpower,
                        physique: character.system.physique,
                        charm: character.system.charm,
                        wits: character.system.wits
                    };
                }
            }
        } else {
            // For players: Show data for their assigned character
            const character = game.user.character;
            if (character) {
                actorData = {
                    health: character.system.health,
                    reputation: character.system.reputation,
                    willpower: character.system.willpower,
                    physique: character.system.physique,
                    charm: character.system.charm,
                    wits: character.system.wits
                    // Add more stats as needed
                };
            }
        }
    
        return actorData;
    }
    

    activateListeners(html) {
        super.activateListeners(html);
        // Add event listeners for your buttons here
        html.find('.some-button-class').click(this._onButtonClick.bind(this));
    }

    _onButtonClick(event) {
        event.preventDefault();
        // Handle button click
    }
}
