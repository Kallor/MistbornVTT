import { PlayerSidebar } from "./combat-sidebar.mjs";

Hooks.on("updateCombat", (combat, update, options, userId) => {
    if (combat.started && game.user.id === userId) {
        // Render the sidebar when an encounter starts
        new PlayerSidebar().render(true);
    }
});

Hooks.on("deleteCombat", (combat, options, userId) => {
    if (game.user.id === userId) {
        // Close the sidebar when the encounter ends
        if (PlayerSidebar.instance) {
            PlayerSidebar.instance.close();
        }
    }
});