import { MistRoll } from "./mist-roll.js";
import { Utils } from "./utils/utils.js";
import { rollD6 } from './mb-roll.mjs';

Hooks.on('chatMessage', (chatLog, messageText, chatData) => {
    // Check if the message starts with '/mb' or '/mbroll'
    if (messageText.startsWith("/mb") || messageText.startsWith("/mbroll")) {
        // Prevent the default chat message
        chatData.preventDefault();

        // Extract the number of dice to roll
        // Assuming the command format is "/mbroll [number]" or "/mb [number]"
        const parts = messageText.split(" ");
        let numDice = 1; // Default to 1 die if no number is provided

        if (parts.length > 1 && !isNaN(parts[1])) {
            numDice = parseInt(parts[1]);
        }

        // Call the dice roll function and handle the result
        rollD6(numDice).then(roll => {
            console.log("Rolled dice:", roll);
            // Additional handling for the roll result
        });

        return false; // Return false to prevent the default chat message processing
    }
});

/*
Hooks.on("chatMessage", (html, content, msg) => {
    let regExp;
    regExp = /^\/(m\s)?(mist\s)?/g;    
    let command = content.replace(regExp,"");
    if(command === content){
        // no match of command
        return true;
    }
    
    let roll = new MistRoll(command);
    roll.roll(Utils.getSpeakersActor());
    
    return false;
});
*/